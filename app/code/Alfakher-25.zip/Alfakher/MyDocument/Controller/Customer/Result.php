<?php
 
namespace Alfakher\MyDocument\Controller\Customer;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Alfakher\MyDocument\Model\MyDocumentFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\Filesystem;


class Result extends Action
{
    protected $_myDocument;
    protected $resultRedirect;

        /**
     * @var UploaderFactory
     */
    protected $uploaderFactory;
    
    /**
     * @var AdapterFactory
     */
    protected $adapterFactory;
    
    protected $customerSession;
    /**
     * @var Filesystem
     */
    protected $filesystem;


    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Alfakher\MyDocument\Model\MyDocumentFactory $myDocument,
        \Magento\Framework\Controller\ResultFactory $result,
        \Magento\Customer\Model\Session $customerSession,
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem)
    {
        parent::__construct($context);
        $this->_myDocument = $myDocument;
        $this->resultRedirect = $result;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        $this->customerSession = $customerSession;
    }
    public function execute(){
        $post = $this->getRequest()->getPostValue();
        $name = $post['name'];
        $newArray = array();
        foreach($post['name'] as $key => $value){
            $newArray[$key]['name'] = $value;
            $newArray[$key]['expiry_date'] = date('Y-m-d', strtotime($post['expiry_date'][$key]));
        }
        $filesData = $this->getRequest()->getFiles();
        /*echo "<pre>";print_r($_FILES["filename"]);*/

        
        foreach($newArray as $key => $value){
            $model = $this->_myDocument->create();
            if ($filesData) {
        $files = $this->getRequest()->getFiles();
        if (isset($files['filename']) && !empty($files['filename']["name"])){

            try{
                $uploaderFactories = $this->uploaderFactory->create(['fileId' => 'filename']);
                $uploaderFactories->setAllowedExtensions(['jpg', 'jpeg', 'png', 'pdf']);
                $imageAdapter = $this->adapterFactory->create();
            
                $uploaderFactories->addValidateCallback('custom_image_upload',$uploaderFactories,'validateUploadFile');
                                
                // allow folder creation
                $uploaderFactories->setAllowCreateFolders(true);
                /*echo $_FILES['filename']['size'];*/
                $maxsize = 20;
                /*number_format($_FILES['filename']['size'] / 1048576, 2) . ' MB';*/
                if((number_format($_FILES['filename']['size'] / 1048576, 2) >= $maxsize)) {
                    exit('File too large. File must be less than 20 megabytes.');
                }

                // rename file name if already exists 
                $uploaderFactories->setAllowRenameFiles(true);
                $uploaderFactories->setFilesDispersion(true);

                $mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
                $destinationPath = $mediaDirectory->getAbsolutePath('myDocument');
                $result = $uploaderFactories->save($destinationPath);
                if (!$result) {
                    throw new LocalizedException(
                        __('File cannot be saved to path: $1', $destinationPath)
                    );
                }

                $imagePath = 'myDocument'.$result['file'];
                $data['filename'] = $imagePath;
            } catch (\Exception $e) {
                echo $e->getMessage();
            }
            
        }else{
            echo $msg = "File not found!";
        }
        $resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        /*$model = $this->_myDocument->create();*/
        $model->setData($data);
        }
            $model->addData([
            "document_name" => $value['name'],
            "customer_id" => $this->customerSession->getCustomer()->getId(),
            "expiry_date" => $value['expiry_date']
            ]);
            /*echo "<pre>";print_r($model->getData());*/
            $saveData = $model->save();

            /*$model->getData($data);*/
            /*$saveData = $model->save();*/
            if($saveData){
                $this->messageManager->addSuccess( __('Insert Record Successfully !') );
                $res = "1"; //echo "1";
            }else{
                //$this->messageManager->addErrorMessage(__('Data was not saved.'));
                $res = FALSE; //echo "0";
            }

            echo json_encode($res);
        }
        /*return $resultRedirect;*/
    }
}