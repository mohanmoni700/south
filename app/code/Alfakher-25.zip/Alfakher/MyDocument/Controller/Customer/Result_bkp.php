<?php

namespace Alfakher\MyDocument\Controller\Customer;


use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Alfakher\MyDocument\Model\ExtensionFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;

class Result extends Action
{

    protected $resultPageFactory;
    protected $extensionFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        ExtensionFactory $extensionFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->extensionFactory = $extensionFactory;
        parent::__construct($context);
    }

    /*protected $_mediaDirectory;
    protected $_fileUploaderFactory;
     
    public function __construct(
        Context $context,        
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
    ) {
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);
    }*/
    public function execute()
    {
        $post = $this->getRequest()->getPostValue();
        /*echo "<pre>";print_r($post);exit;*/
        if (!$post) {
            $this->_redirect('mydocument/customer/index');
            return;
        }


        
        try {
            $postObject = new \Magento\Framework\DataObject();
            
            $postObject->setData($post);

            $error = false;

            if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
                $error = true;
            }
            if (!\Zend_Validate::is(trim($post['datepicker']), 'NotEmpty')) {
                $error = true;
            }
            
            $filesData = $this->getRequest()->getFiles('filename');

            if ($filesData['name']) {
               $postObject->setFilename($filesData['name']);
            }

            echo "<pre>";print_r($postObject->getData());exit;
            $postObject->setData($data)->save();
                $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
      
        $fileName=['profileAdd']['name'];
        echo $fileName;
        //name of the file is printed which i uploaded from form
    } catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.')
            );
            /*$this->getDataPersistor()->set('contact_us', $post);
            $this->_redirect('contact');*/
            return;
        }
}

}