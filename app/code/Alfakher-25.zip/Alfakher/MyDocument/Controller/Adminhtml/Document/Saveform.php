<?php
namespace Alfakher\MyDocument\Controller\Adminhtml\Document;

use Alfakher\MyDocument\Model\MyDocument;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;

class Saveform extends \Magento\Backend\App\Action implements HttpPostActionInterface
{
    public function __construct(\Magento\Backend\App\Action\Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory, \Magento\Framework\Controller\Result\RedirectFactory $resultRedirectFactory, MyDocument $documentModel, array $data = [])
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->documentModel = $documentModel;
        $this->resultRedirectFactory = $resultRedirectFactory;
        parent::__construct($context);
    }
    public function execute()
    {
        $post = (array)$this->getRequest()->getPost();
        try
        {

            $newArray = array();
            foreach ($post['mydocument_id'] as $key => $value)
            {
                $newArray[$key]['mydocument_id'] = $post['mydocument_id'][$key];
                $newArray[$key]['status'] = empty($post['message'][$key]) ? 1 : 0;
                $newArray[$key]['message'] = $post['message'][$key];
            }
            foreach ($newArray as $key => $value)
            {
                $entity = $this->documentModel->load($value['mydocument_id']);
                if ($entity)
                {
                    $entity->setStatus($value['status']);
                    $entity->setMessage($value['message']);
                    $entity->save();
                }
            }
            $this->messageManager->addSuccess(__('The data has been saved.'));

        }
        catch(\Exception $e)
        {
            $this->messageManager->addErrorMessage(__("Something went wrong."));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setRefererUrl();
        return $resultRedirect;

    }
}

