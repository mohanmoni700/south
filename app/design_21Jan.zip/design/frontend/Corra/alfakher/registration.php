<?php
/**
 * CORRA
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::THEME, 'frontend/Corra/alfakher', __DIR__);
